import UIKit


var counter : Int = 0
var theend : Int = 100
var buzz : String = "buzz"
var fizz : String = "Fizz"
var fb : String = "FizzBuzz"
var prime : String = "prime"


while counter < theend {
    counter += 1
    //print(counter)
    if (counter % 3 == 0 ){
        print(fizz)
       // print(counter)
        if (counter % 5 == 0){
            print(fb)
            print(counter)
        }
    } else if (counter % 5 == 0){
        print(buzz)
      //  print(counter)
    }  else {
        continue
    }
    /*
    for number in 2...100{
        if (counter % counter == 0 && counter % number != 0){
            continue
        } else {
            print(prime)
            print(counter)
        }
    }*/
}




//var str = "Hello, playground"
