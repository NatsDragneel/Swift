import UIKit


/* what is tuples?
 it is some variables or constants with multiples values and it is easy to store.
 
 what is array
 it is to save different kind of characters and  some values in a sigle array or multi arrays
 
 the differences between tuples and array is the tuple works with a few variables or constanst and it is hard to work with a massive data base on it, while with arrays it is easier to work on multiples variables and constants and more array within arrays. in array is simple to retrieve item within a massive data base.
 
 In game, it would be usefull to use tuple when the game is working with 2 data types, for example1, HP 150. as the game goes and you are taking damage the date type int would be the one decreasing while HP is intact. this is applicable only if you are taking HP in consideration.
 in game , it would be usefull to use array when the game is working with 2 or more data types and more arrays, for example2 in raids, you are working with hp 150, mp 150, sp 150, all this array would be in the array and it would be easier to work with becuase your hp,mp and sp would be intact while the values of each one would be decreasing or increasing depending on how it is set up.
 */
//example 1

var characterInfo1 : [(String,Int)] = [("HP",150)] // this is the display of the character info
let oldHP = [("HP",140)]
characterInfo1 = oldHP



// example 2

var characterInfo2 : [(String, Int)] = [("HP",150),("MP",150),("SP",150)]
// while you are in raids, values of 150 of each character would decrease or increase

let newHP = [("HP",130),("MP",100),("SP",180)] // this would be applied after 5 sec on the raids
characterInfo2 = newHP
 // also we could insert some new power up on the character or remove it after while.
characterInfo2 += [("power up", 150)] // added at the end of the array


// ranges is to specify the limit of the array or tuple.

var str = "Hello, playground"
