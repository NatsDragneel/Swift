import UIKit


var clock : [(String, Int)] = [("hours", 23), ("day",24),("hours", 25)]

func timeAdder(clock : [(String , Int)]) -> (String, Int){
    var realNumber : Int = 0
    var realName : String = ""
    
    for (name, quantity) in clock {
        switch (name, quantity) {
        case ("hours", 1..<24) :
            realName = "hours"
            realNumber = quantity
        case ("hours", 24) :
            realName = "days"
            realNumber = 1
        case ("hours", 25..<47) :
            realName = "hours"
            realNumber = quantity
        case ("hours", 48) :
            realName = "days"
            realNumber = 2
        case ("hours", 49..<71 ) :
            realName = "hours"
            realNumber = quantity
        case ("hours", 72):
            realName = "days"
            realNumber = 3
        case ("days", 1..<4):
            realName = name
            realNumber = quantity
        default:
            print("This is invalid input")
        }
    }
    return (realName, realNumber)
}

let result2 = timeAdder(clock : [("days" , 6)])

//var str = "Hello, playground"
